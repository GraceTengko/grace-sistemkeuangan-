<?php

namespace App\Libraries;

use App\Models\PenggunaModel;

class Authentication
{
    protected $userModel;
    protected $user;

    public function __construct()
    {
        $this->userModel = new PenggunaModel();
    }

    // Method untuk login
    public function login($user)
    {
        // Simpan data pengguna di session
        session()->set([
            'user_id' => $user['id'],
            'role' => $user['role'],
            'isLoggedIn' => true
        ]);

        $this->user = $user;
        log_message('debug', 'User logged in: ' . json_encode(session()->get()));
    }

    // Method untuk memeriksa status login
    public function check()
    {
        return session()->get('isLoggedIn') ?? false;
    }

    // Method untuk mendapatkan pengguna yang sedang login
    public function user()
    {
        if ($this->user) {
            return $this->user;
        }

        $userId = session()->get('user_id');
        if ($userId) {
            $this->user = $this->userModel->find($userId);
        }

        return $this->user;
    }

    // Method untuk logout
    public function logout()
    {
        session()->remove(['user_id', 'role', 'isLoggedIn']);
        $this->user = null;
    }
}
