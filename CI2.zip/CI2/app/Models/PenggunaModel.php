<?php

namespace App\Models;

use CodeIgniter\Model;

class PenggunaModel extends Model
{
    protected $table = 'pengguna'; // Specify the table name
    protected $allowedFields = ['namapengguna', 'telepon', 'username', 'password', 'role']; // Fields that are allowed to be inserted/updated

    // Optional: Set the primary key if needed
    protected $primaryKey = 'id';

    // Optional: Set return type for consistency (array or object)
    protected $returnType = 'array';

    // Aturan validasi
    protected $validationRules = [
        'username' => 'required|is_unique[pengguna.username,id,{id}]', // Ganti {id} saat update
        'namapengguna' => 'required',
        'telepon' => 'required',
        'password' => 'permit_empty', // Password tidak wajib
        'role' => 'required'
    ];

    // Optional: Set custom error messages
    protected $validationMessages = [
        'username' => [
            'is_unique' => 'Username sudah digunakan, silakan pilih username lain.'
        ]
    ];

    /**
     * Get all pengguna data
     */
    public function getAllData()
    {
        return $this->findAll(); // Use the built-in findAll() method
    }

    /**
     * Add new pengguna data
     * @param array $data
     * @return bool
     */
    public function tambah($data)
    {
        return $this->insert($data); // Use the built-in insert() method
    }

    /**
     * Set validation rules for update operation
     * @param int $id
     */
    public function setValidationRulesForUpdate($id)
    {
        $this->validationRules['username'] = 'required|is_unique[pengguna.username,id,' . $id . ']'; // Memperbolehkan username yang sama saat update
    }
}