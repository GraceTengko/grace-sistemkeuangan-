<?php

namespace App\Models;

use CodeIgniter\Model;

class KategoriModel extends Model
{
    protected $table = 'kategori';
    protected $primaryKey = 'id';
    protected $allowedFields = ['kategori'];

    public function update($id = null, $data = null): bool
    {
        // Pastikan $data tidak null dan mengandung updated_at
        if ($data !== null) {
            $data['updated_at'] = date('Y-m-d H:i:s'); // Menyimpan timestamp saat ini
        }

        return parent::update($id, $data); // Memanggil metode update dari kelas Model
    }
}