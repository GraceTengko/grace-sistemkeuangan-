<?php

namespace App\Models;

use CodeIgniter\Model;

class TransaksiModel extends Model
{
    protected $table = 'transaksi'; // Nama tabel
    protected $primaryKey = 'id'; // Kunci utama tabel
    protected $allowedFields = ['nomor_kuitansi', 'tanggal', 'kategori', 'keterangan', 'pemasukan', 'pengeluaran', 'created_at']; // Kolom yang diizinkan

    // Mengambil semua transaksi
    public function getTransaksi()
    {
        return $this->select('nomor_kuitansi, tanggal, kategori, keterangan, pemasukan, pengeluaran, created_at')
                    ->findAll(); // Ambil semua transaksi
    }

    // Menghitung total saldo berdasarkan kategori
    public function getTotalSaldoByKategori()
    {
        return $this->select('kategori, SUM(pemasukan) as total_pemasukan, SUM(pengeluaran) as total_pengeluaran')
                    ->groupBy('kategori')
                    ->findAll(); // Hitung total berdasarkan kategori
    }

    // Mengambil laporan bulanan
    public function getLaporanBulanan()
    {
        return $this->select('kategori, MONTH(tanggal) as bulan, YEAR(tanggal) as tahun, SUM(pemasukan) as total_pemasukan, SUM(pengeluaran) as total_pengeluaran')
                    ->groupBy('kategori, MONTH(tanggal), YEAR(tanggal)')
                    ->orderBy('tanggal', 'DESC')
                    ->findAll(); // Ambil laporan bulanan
    }

    // Mengambil data transaksi dengan pagination
    public function getPagination($perPage = 10)
    {
        return $this->paginate($perPage); // Mengambil data per halaman
    }

    // Di dalam TransaksiModel
    public function getDetailKeuangan($bulan, $tahun)
    {
        return $this->where('MONTH(tanggal)', $bulan)
                    ->where('YEAR(tanggal)', $tahun)
                    ->findAll();
    } 

    public function getTotalSaldoByKategoriAndYear($year)
{
    $builder = $this->db->table('transaksi');
    $builder->select('kategori, SUM(pemasukan) as total_pemasukan, SUM(pengeluaran) as total_pengeluaran');
    $builder->where('YEAR(tanggal)', $year);
    $builder->groupBy('kategori');
    return $builder->get()->getResultArray();
}
public function getTotalSaldoByKategoriAndMonthYear($month, $year)
{
    $builder = $this->db->table('transaksi');
    $builder->select('kategori, SUM(pemasukan) as total_pemasukan, SUM(pengeluaran) as total_pengeluaran');
    $builder->where('YEAR(tanggal)', $year);
    $builder->where('MONTH(tanggal)', $month);
    $builder->groupBy('kategori');
    return $builder->get()->getResultArray();
}


}