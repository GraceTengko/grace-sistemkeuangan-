<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class RoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Periksa apakah sesi pengguna tersedia
        if (!session()->has('sesusername') || !session()->has('role')) {
            // Jika sesi tidak ada, redirect ke halaman login
            return redirect()->to('/login')->with('error', 'Anda harus login terlebih dahulu.');
        }

        // Mengambil role pengguna dari sesi
        $userRole = session()->get('role'); // Misalnya: 'Operator', 'Admin', dll.

        // Pastikan $arguments berisi role yang diizinkan
        if (empty($arguments) || !is_array($arguments)) {
            // Jika tidak ada argumen role yang diberikan, redirect ke halaman Forbidden
            return redirect()->to('/forbidden')->with('error', 'Akses ditolak. Peran tidak ditentukan.');
        }

        // Debugging: Catat role pengguna dan role yang diizinkan
        log_message('debug', 'Role pengguna: ' . $userRole);
        log_message('debug', 'Role yang diizinkan: ' . implode(', ', $arguments));

        // Periksa apakah role pengguna ada dalam daftar role yang diizinkan
        if (!in_array($userRole, $arguments)) {
            // Jika role tidak sesuai, redirect ke halaman Forbidden
            return redirect()->to('/noakses')->with('error', 'Anda tidak memiliki akses ke halaman ini.');
        }

        // Jika lolos validasi, lanjutkan ke controller
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Filter ini tidak memerlukan aksi setelah request
    }
}
