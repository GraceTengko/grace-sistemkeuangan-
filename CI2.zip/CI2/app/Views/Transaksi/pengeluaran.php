<div class="card">
<h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

    <div class="card-header">
        <h4 style="color: black;">Tabel Pengeluaran Bulan <?= date('F Y'); ?></h4> <!-- Menampilkan bulan dan tahun sekarang -->
    </div>
     <!-- Tambahkan style untuk tabel manual -->
     <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th style="color: black;">No</th>
                    <th style="color: black;">Nomor Keputusan Komite</th>
                    <th style="color: black;">Tanggal</th>
                    <th style="color: black;">Kategori</th>
                    <th style="color: black;">Keterangan</th>
                    <th style="color: black;">Nomor Nota</th>
                    <th style="color: black;">Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <!-- Inisialisasi variabel nomor urut -->
                <?php $j = 1; ?>
                <!-- Looping data transaksi pengeluaran -->
                <?php foreach ($transaksi as $row) : ?>
                    <?php if ($row['pengeluaran'] > 0) : ?>
                        <tr style="color: black;">
                            <td><?= $j++; ?></td>
                            <td><?= esc($row['nomor_kuitansi']); ?></td>
                            <td><?= date('d-m-Y', strtotime($row['tanggal'])); ?></td>
                            <td><?= esc($row['kategori']); ?></td>
                            <td><?= esc($row['keterangan']); ?></td>
                            <td><?= esc($row['nomor_nota']); ?></td>
                            <td><?= 'Rp. ' . number_format($row['pengeluaran'], 2, ',', '.'); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
