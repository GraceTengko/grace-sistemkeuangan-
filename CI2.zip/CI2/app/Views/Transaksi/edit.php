<div class="container-fluid">

    <!-- Menampilkan Alert jika ada -->
    <?php if (session()->getFlashdata('message')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Berhasil!</strong> <?= session()->getFlashdata('message'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Menampilkan Error jika ada -->
    <?php if (session()->getFlashdata('error')) : ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Gagal!</strong> <?= session()->getFlashdata('error'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5 style="color: black;">Edit Transaksi</h5>
        </div>
        <div class="card-body">
            <!-- Form Edit Transaksi -->
            <form action="<?= base_url('transaksi/update/' . $transaksi['id']) ?>" method="post">
                <div class="form-group">
                    <label for="nomor_kuitansi" style="color: black;">Nomor Kwitansi</label>
                    <input type="text" class="form-control" id="nomor_kuitansi" name="nomor_kuitansi" value="<?= $transaksi['nomor_kuitansi'] ?>" required>
                </div>

                <div class="form-group">
                    <label for="tanggal" style="color: black;">Tanggal</label>
                    <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $transaksi['tanggal'] ?>" required>
                </div>

                <div class="form-group">
                    <label for="kategori" style="color: black;">Kategori</label>
                    <select class="form-control" id="kategori" name="kategori" required>
                        <option value="Perpuluhan" <?= $transaksi['kategori'] == 'Perpuluhan' ? 'selected' : '' ?>>Perpuluhan</option>
                        <option value="Persembahan Terpadu Konferens" <?= $transaksi['kategori'] == 'Persembahan Terpadu Konferens' ? 'selected' : '' ?>>Persembahan Terpadu Konferens</option>
                        <option value="Pelayanan Perorangan" <?= $transaksi['kategori'] == 'Pelayanan Perorangan' ? 'selected' : '' ?>>Pelayanan Perorangan</option>
                        <option value="Bidang Pelayanan Sekolah Sabat" <?= $transaksi['kategori'] == 'Bidang Pelayanan Sekolah Sabat' ? 'selected' : '' ?>>Bidang Pelayanan Sekolah Sabat</option>
                        <option value="Bidang Pelayanan Anak-anak" <?= $transaksi['kategori'] == 'Bidang Pelayanan Anak-anak' ? 'selected' : '' ?>>Bidang Pelayanan Anak-anak</option>
                        <option value="Bidang Pelayanan Rumah Tangga" <?= $transaksi['kategori'] == 'Bidang Pelayanan Rumah Tangga' ? 'selected' : '' ?>>Bidang Pelayanan Rumah Tangga</option>
                        <option value="Bidang Pelayanan PA" <?= $transaksi['kategori'] == 'Bidang Pelayanan PA' ? 'selected' : '' ?>>Bidang Pelayanan PA</option>
                        <option value="Penatalayanan" <?= $transaksi['kategori'] == 'Penatalayanan' ? 'selected' : '' ?>>Penatalayanan</option>
                        <option value="BWA" <?= $transaksi['kategori'] == 'BWA' ? 'selected' : '' ?>>BWA</option>
                        <option value="Pembangunan" <?= $transaksi['kategori'] == 'Pembangunan' ? 'selected' : '' ?>>Pembangunan</option>
                        <option value="Pendidikan" <?= $transaksi['kategori'] == 'Pendidikan' ? 'selected' : '' ?>>Pendidikan</option>
                        <option value="Kas Gereja" <?= $transaksi['kategori'] == 'Kas Gereja' ? 'selected' : '' ?>>Kas Gereja</option>
                        <option value="Lainnya" <?= $transaksi['kategori'] == 'Lainnya' ? 'selected' : '' ?>>Lainnya</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="keterangan" style="color: black;">Keterangan</label>
                    <input type="text" class="form-control" id="keterangan" name="keterangan" value="<?= $transaksi['keterangan'] ?>" required>
                </div>

                <div class="form-group">
                    <label for="pemasukan" style="color: black;">Pemasukan</label>
                    <input type="number" class="form-control" id="pemasukan" name="pemasukan" value="<?= $transaksi['pemasukan'] ?>" min="0" step="0.01">
                </div>

                <div class="form-group">
                    <label for="pengeluaran" style="color: black;">Pengeluaran</label>
                    <input type="number" class="form-control" id="pengeluaran" name="pengeluaran" value="<?= $transaksi['pengeluaran'] ?>" min="0" step="0.01">
                </div>

                <button type="submit" class="btn btn-primary">Update</button>
                <a href="<?= base_url('transaksi/opsitransaksi'); ?>" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>

    <script>
        const pemasukanInput = document.getElementById('pemasukan');
        const pengeluaranInput = document.getElementById('pengeluaran');

        pemasukanInput.addEventListener('input', function() {
            if (pemasukanInput.value > 0) {
                pengeluaranInput.disabled = true;
                pengeluaranInput.value = ''; // Kosongkan pengeluaran jika pemasukan diisi
            } else {
                pengeluaranInput.disabled = false;
            }
        });

        pengeluaranInput.addEventListener('input', function() {
            if (pengeluaranInput.value > 0) {
                pemasukanInput.disabled = true;
                pemasukanInput.value = ''; // Kosongkan pemasukan jika pengeluaran diisi
            } else {
                pemasukanInput.disabled = false;
            }
        });
    </script>
</div>