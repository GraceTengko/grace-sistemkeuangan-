<div class="container-fluid">
<h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

    <!-- Menampilkan Alert jika ada -->
    <?php if (session()->getFlashdata('message')) : ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> <?= session()->getFlashdata('message'); ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <!-- Menampilkan Error jika ada -->
    <?php if (session()->getFlashdata('error')) : ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Gagal!</strong> <?= session()->getFlashdata('error'); ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target="#addTransactionModal">
                            Tambah Transaksi
                        </button>
                        <a href="<?= base_url('transaksi'); ?>" class="btn btn-secondary">
                            Kembali ke Halaman Data Transaksi
                        </a>
                    </div>
                </div>
            </div>

            <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th style="color: black;">No</th>
                    <th style="color: black;">Nomor Kuitansi</th>
                    <th style="color: black;">Tanggal</th>
                    <th style="color: black;">Kategori</th>
                    <th style="color: black;">Keterangan</th>
                    <th style="color: black;">Jumlah</th>
                    <th style="color: black;">Booked</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($transaksi)) : ?>
                    <tr>
                        <td colspan="9" class="text-center" style="color: black;">Data tidak ditemukan.</td>
                    </tr>
                <?php else : ?>
                    <?php $i = 1; ?>
                    <?php foreach ($transaksi as $row) : ?>
                        <tr style="color: black;">
                            <td><?= $i; ?></td>
                            <td><?= esc($row['nomor_kuitansi']); ?></td>
                            <td><?= esc($row['tanggal']); ?></td>
                            <td><?= esc($row['kategori']); ?></td> <!-- Menampilkan nama kategori -->
                            <td><?= esc($row['keterangan']); ?></td>
                            <td><?= 'Rp. ' . number_format($row['pemasukan'], 2, ',', '.'); ?></td>
                            <td><?= esc($row['created_at']); ?></td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center">
                <?php if ($pager): ?>
                    <?= $pager->links('default', 'bootstrap_pagination') ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal untuk Tambah Transaksi -->
<div class="modal fade" id="addTransactionModal" tabindex="-1" role="dialog" aria-labelledby="addTransactionModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addTransactionModalLabel" style="color: black;">Tambah Transaksi</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" style="color: black;">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="color: black;">
                <form action="<?= base_url('transaksi/tambah') ?>" method="post">
                    <div class="form-group">
                        <label for="nomor_kuitansi" style="color: black;">Nomor Kuitansi</label>
                        <input type="text" class="form-control" id="nomor_kuitansi" name="nomor_kuitansi" required>
                    </div>
                    <div class="form-group">
                        <label for="tanggal" style="color: black;">Tanggal</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                    </div>
                    <div class="form-group">
                        <label for="kategori" style="color: black;">Kategori</label>
                        <select class="form-control" id="kategori" name="kategori" required>
                            <option value="Perpuluhan">Perpuluhan</option>
                            <option value="Persembahan Terpadu Konferens">Persembahan Terpadu Konferens</option>
                            <option value="Persembahan Terpadu Jemaat">Persembahan Terpadu Jemaat</option>
                            <option value="Pelayanan Perorangan">Pelayanan Perorangan</option>
                            <option value="Bidang Pelayanan Sekolah Sabat">Bidang Pelayanan Sekolah Sabat</option>
                            <option value="Bidang Pelayanan Anak-anak">Bidang Pelayanan Anak-anak</option>
                            <option value="Bidang Pelayanan Rumah Tangga">Bidang Pelayanan Rumah Tangga</option>
                            <option value="Bidang Pelayanan PA">Bidang Pelayanan PA</option>
                            <option value="Penatalayanan">Penatalayanan</option>
                            <option value="BWA">BWA</option>
                            <option value="Pembangunan">Pembangunan</option>
                            <option value="Pendidikan">Pendidikan</option>
                            <option value="Kas Gereja">Kas Gereja</option>
                            <option value="Persembahan Ibadah Gabungan Dorkas BWA AP">Persembahan Ibadah Gabungan Dorkas BWA AP</option>
                            <option value="Lainnya">Lainnya</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="keterangan" style="color: black;">Keterangan</label>
                        <textarea class="form-control" id="keterangan" name="keterangan" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="pemasukan" style="color: black;">Pemasukan</label>
                        <input type="text" class="form-control" id="pemasukan" name="pemasukan" required placeholder="Masukkan saldo (contoh: 2000000 untuk 2.000.000)">
                    </div>
                    <div class="form-group">
                        <label for="pengeluaran" style="color: black;">Pengeluaran</label>
                        <input type="text" class="form-control" id="pengeluaran" name="pengeluaran" required placeholder="Masukkan saldo (contoh: 2000000 untuk 2.000.000)">
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal" style="color: black;">Tutup</button>
                        <button type="submit" class="btn btn-primary" style="color: black;">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    const pemasukanInput = document.getElementById('pemasukan');
    const pengeluaranInput = document.getElementById('pengeluaran');

    pemasukanInput.addEventListener('input', function() {
        if (pemasukanInput.value > 0) {
            pengeluaranInput.disabled = true;
            pengeluaranInput.value = 0;
        } else {
            pengeluaranInput.disabled = false;
        }
    });

    pengeluaranInput.addEventListener('input', function() {
        if (pengeluaranInput.value > 0) {
            pemasukanInput.disabled = true;
            pemasukanInput.value = 0;
        } else {
            pemasukanInput.disabled = false;
        }
    });
</script>
