<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

    <!-- Tambahkan style untuk tabel manual -->
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>

    <div class="card shadow">
        <div class="card-header">
            <h4 class="text-dark">Tabel Pemasukan Bulan <?= date('F Y'); ?></h4>
        </div>
        <div class="card-body">
            <!-- Tabel Manual -->
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nomor Kuitansi</th>
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Keterangan</th>
                        <th>Jumlah</th>
                        <th>Booked</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Inisialisasi variabel nomor urut -->
                    <?php $i = 1; ?>
                    <!-- Looping data transaksi -->
                    <?php foreach ($transaksi as $row) : ?>
                        <?php if ($row['pemasukan'] > 0) : ?>
                            <tr>
                                <td><?= $i++; ?></td>
                                <td><?= esc($row['nomor_kuitansi']); ?></td>
                                <td><?= date('d-m-Y', strtotime($row['tanggal'])); ?></td>
                                <td><?= esc($row['kategori']) ?: '-'; ?></td>
                                <td><?= esc($row['keterangan']) ?: '-'; ?></td>
                                <td><?= 'Rp. ' . number_format($row['pemasukan'], 2, ',', '.'); ?></td>
                                <td><?= date('d-m-Y H:i:s', strtotime($row['created_at'])); ?></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
