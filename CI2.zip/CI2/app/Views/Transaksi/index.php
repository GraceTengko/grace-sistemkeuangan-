<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

    <!-- Menampilkan Alert jika ada -->
    <?php if (session()->getFlashdata('message')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Berhasil!</strong> <?= session()->getFlashdata('message'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- Opsi Transaksi dalam Card -->
    <div class="row">
        <!-- Card untuk Transaksi Pemasukkan -->
        <div class="col-md-6 mb-3">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="card-title mb-0">Pemasukkan</h5>
                </div>
                <div class="card-body">
                    <a href="<?= base_url('transaksi/pemasukan'); ?>" class="btn btn-success btn-block">
                        Transaksi Pemasukkan
                    </a>
                </div>
                <div class="card-body">
                    <a href="<?= base_url('transaksi/opsitransaksipemasukan'); ?>" class="btn btn-success btn-block">
                        Kelola Transaksi Pemasukkan
                    </a>
                </div>
            </div>
        </div>

        <!-- Card untuk Transaksi Pengeluaran -->
        <div class="col-md-6 mb-3">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">Pengeluaran</h5>
                </div>
                <div class="card-body">
                    <a href="<?= base_url('transaksi/pengeluaran'); ?>" class="btn btn-danger btn-block">
                        Transaksi Pengeluaran
                    </a>
                </div>
                <div class="card-body">
                    <a href="<?= base_url('transaksi/opsitransaksipengeluaran'); ?>" class="btn btn-danger btn-block">
                        Kelola Transaksi Pengeluaran
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>