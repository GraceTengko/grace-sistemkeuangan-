<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Bulan</th>
                <th>Total Pemasukan</th>
                <th>Total Pengeluaran</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($laporan_bulanan as $row) : ?>
                <tr>
                    <td><?= $row['bulan']; ?></td>
                    <td><?= 'Rp. ' . number_format($row['total_pemasukan'], 2, ',', '.'); ?></td>
                    <td><?= 'Rp. ' . number_format($row['total_pengeluaran'], 2, ',', '.'); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
