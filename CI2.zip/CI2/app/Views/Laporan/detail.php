<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Menampilkan Detail Transaksi Pada Bulan <?= esc($bulan) ?> yang Dipilih</h1>

    <style>
        table td, table th {
            color: black; /* Mengatur warna teks dalam tabel menjadi hitam */
        }
    </style>
    
    <!-- Pencarian -->
    <div class="card mb-3">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <form class="form-inline" action="<?= base_url('laporan/detail'); ?>" method="get">
                    <input class="form-control mr-2" type="search" name="search" value="<?= esc($search ?? '') ?>" placeholder="Cari Nomor Kuitansi" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Cari</button>
                </form>
                <div class="d-flex align-items-center">
                    <a href="<?= base_url('laporan'); ?>" class="btn btn-secondary">
                        Kembali ke Halaman Laporan
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nomor Kuitansi</th>
                    <th>Tanggal</th>
                    <th>Kategori</th>
                    <th>Keterangan</th>
                    <th>Pemasukan</th>
                    <th>Pengeluaran</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($detailData)) : ?>
                    <tr>
                        <td colspan="7" class="text-center">Data tidak ditemukan.</td>
                    </tr>
                <?php else : ?>
                    <?php $currentPage = $currentPage ?? 1; ?>
                    <?php $i = 1 + (10 * ($currentPage - 1)); ?>
                    <?php
                    // Mengambil bulan dan tahun dari variabel (asumsi sudah ada)
                    $selectedMonth = $bulan; // Misalnya bulan yang dipilih
                    $selectedYear = $tahun ?? date('Y'); // Gunakan tahun saat ini jika tidak ada

                    // Menampilkan detail data berdasarkan bulan dan tahun yang sama
                    foreach ($detailData as $row) :
                        // Mengambil bulan dan tahun dari tanggal
                        $dataMonth = date('m', strtotime($row['tanggal']));
                        $dataYear = date('Y', strtotime($row['tanggal']));

                        // Memfilter data untuk menampilkan hanya yang sesuai dengan bulan dan tahun yang dipilih
                        if ($dataMonth == $selectedMonth && $dataYear == $selectedYear) :
                    ?>
                            <tr>
                                <td><?= $i++; ?></td>
                                <td><?= esc($row['nomor_kuitansi']); ?></td>
                                <td><?= date('d-m-Y', strtotime($row['tanggal'])); ?></td>
                                <td><?= esc($row['kategori']); ?></td>
                                <td><?= esc($row['keterangan']); ?></td>
                                <td><?= $row['pemasukan']; ?></td>
                                <td><?= $row['pengeluaran']; ?></td>
                            </tr>
                    <?php
                        endif; // Akhir dari if untuk memfilter data
                    endforeach; // Akhir dari foreach
                    ?>
                <?php endif; // Akhir dari if untuk pengecekan data ?>
            </tbody>
        </table>

        <script>
            // Fungsi untuk memperbarui laporan berdasarkan tahun yang dipilih
            function updateLaporan() {
                const selectedYear = document.getElementById('tahunSelect').value;
                document.getElementById('tahunLaporan').textContent = selectedYear;

                // Ambil data laporan untuk tahun yang dipilih
                fetch(`<?= base_url('laporan/getKeuanganData') ?>?tahun=${selectedYear}`)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log(data); // Periksa data yang diterima
                        let tableBody = document.getElementById('laporanKeuanganTable');
                        tableBody.innerHTML = ''; // Kosongkan tabel sebelum diisi

                        // Cek apakah data kosong
                        if (data.length === 0) {
                            tableBody.innerHTML = '<tr><td colspan="4" class="text-center">Tidak ada data laporan.</td></tr>';
                        } else {
                            const namaBulan = [
                                "Januari", "Februari", "Maret", "April", "Mei", "Juni", 
                                "Juli", "Agustus", "September", "Oktober", "November", "Desember"
                            ];

                            // Iterasi data dan tambahkan ke tabel
                            data.forEach(item => {
                                let pemasukan = item.pemasukan !== null && !isNaN(item.pemasukan) ? item.pemasukan : 0;
                                let pengeluaran = item.pengeluaran !== null && !isNaN(item.pengeluaran) ? item.pengeluaran : 0;

                                let row = `<tr>
                                    <td>${namaBulan[item.bulan - 1]}</td> <!-- Menampilkan nama bulan -->
                                    <td>${item.pemasukan}</td>
                                    <td>${item.pengeluaran}</td>
                                    <td>
                                        <a href="<?= base_url('laporan/getDetailKeuangan') ?>?bulan=${item.bulan}&tahun=${selectedYear}" class="btn btn-info btn-sm">Detail</a>
                                    </td>
                                </tr>`;
                                tableBody.innerHTML += row;
                            });
                        }
                    })
                    .catch(error => console.error('Error:', error));
            }

            // Ambil data laporan saat halaman dimuat untuk tahun saat ini
            updateLaporan();
        </script>

        <!-- Pagination -->
        <div class="d-flex justify-content-center">
            <?= $pager->links('default', 'bootstrap_pagination') ?>
        </div>
    </div>
</div>