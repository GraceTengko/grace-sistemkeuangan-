<div class="container">
    <h2>Laporan Keuangan Tahun <span id="tahunLaporan"><?= date('Y'); ?></span></h2>

    <style>
        table td, table th {
            color: black; /* Mengatur warna teks dalam tabel menjadi hitam */
        }
    </style>
    
    <div class="form-group">
        <label for="tahunSelect">Pilih Tahun:</label>
        <select id="tahunSelect" class="form-control" onchange="updateLaporan()">
            <?php 
            // Menghasilkan pilihan tahun dari 2020 hingga tahun sekarang
            $currentYear = date('Y');
            for ($year = $currentYear; $year >= 2015; $year--) {
                echo "<option value='$year'>$year</option>";
            }
            ?>
        </select>
    </div>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th style="color: black;">Bulan</th>
                <th style="color: black;">Pemasukan (Rp)</th>
                <th style="color: black;">Pengeluaran (Rp)</th>
                <th style="color: black;">Saldo</th> <!-- Kolom untuk detail -->
                <th style="color: black;">Detail</th> <!-- Kolom untuk detail -->
            </tr>
        </thead>
        <tbody id="laporanKeuanganTable">
            <!-- Data akan diisi dengan AJAX -->
        </tbody>
    </table>
</div>

<script>
    // Fungsi untuk memperbarui laporan berdasarkan tahun yang dipilih
    function updateLaporan() {
        const selectedYear = document.getElementById('tahunSelect').value;
        document.getElementById('tahunLaporan').textContent = selectedYear;

        // Ambil data laporan untuk tahun yang dipilih
        fetch(`<?= base_url('laporan/getKeuanganData') ?>?tahun=${selectedYear}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                console.log(data); // Periksa data yang diterima
                let tableBody = document.getElementById('laporanKeuanganTable');
                tableBody.innerHTML = ''; // Kosongkan tabel sebelum diisi

                let saldo = 0; // Inisialisasi saldo awal

                // Cek apakah data kosong
                if (data.length === 0) {
                    tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Tidak ada data laporan.</td></tr>';
                } else {
                    const namaBulan = [
                        "Januari", "Februari", "Maret", "April", "Mei", "Juni", 
                        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
                    ];

                    // Iterasi data dan tambahkan ke tabel
                    data.forEach(item => {
                        let pemasukan = item.pemasukan !== null && !isNaN(item.pemasukan) ? parseFloat(item.pemasukan.replace(/[^\d.-]/g, '')) : 0;
                        let pengeluaran = item.pengeluaran !== null && !isNaN(item.pengeluaran) ? parseFloat(item.pengeluaran.replace(/[^\d.-]/g, '')) : 0;

                        saldo += pemasukan - pengeluaran; // Hitung saldo kumulatif

                        let row = `<tr>
                            <td>${namaBulan[item.bulan - 1]}</td> <!-- Menampilkan nama bulan -->
                            <td>${item.pemasukan}</td>
                            <td>${item.pengeluaran}</td>
                            <td>${item.saldo}</td> <!-- Saldo langsung dari backend -->
                            <td>
                                <a href="<?= base_url('laporan/getDetailKeuangan') ?>?bulan=${item.bulan}&tahun=${selectedYear}" class="btn btn-info btn-sm">Detail</a>
                            </td>
                        </tr>`;
                        tableBody.innerHTML += row;
                    });
                }
            })
            .catch(error => console.error('Error:', error));
    }

    // Ambil data laporan saat halaman dimuat untuk tahun saat ini
    updateLaporan();
</script>
