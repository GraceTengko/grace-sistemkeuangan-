<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi Keuangan Jemaat GMAHK Pioneer Tumpaan</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <!-- Hero Section -->
    <section class="jumbotron text-center" style="background-color: #ADD8E6;">
        <div class="container">
            <h1 class="jumbotron-heading">Selamat Datang</h1>
            <p class="lead text-muted">Kami hadir untuk melayani Anda dengan cinta dan kesetiaan, serta transparansi dalam pengelolaan keuangan jemaat.</p>
        </div>
    </section>

    <!-- Tentang Kami Section -->
    <section id="tentang" class="container mb-5">
        <h2 class="text-center mb-4">Tentang Kami</h2>
        <div class="row d-flex justify-content-center">
            <div class="col-md-3 text-center">
                <h4>Pendeta Jemaat</h4>
                <p>Pendeta Edwin Kemur adalah pemimpin rohani kami yang berdedikasi untuk membimbing jemaat dalam pelayanan, pengajaran, dan kasih Kristus.</p>
            </div>
            <div class="col-md-3 text-center">
                <h4>Ketua I</h4>
                <p>Reipol Natari bertanggung jawab atas pengaturan kegiatan jemaat, menjamin keberlangsungan acara-acara ibadah dan komunitas di gereja.</p>
            </div>
            <div class="col-md-3 text-center">
                <h4>Ketua II</h4>
                <p>Gledies Kalangi bertanggung jawab atas pengaturan kegiatan jemaat, menjamin keberlangsungan acara-acara ibadah dan komunitas di gereja.</p>
            </div>
            <div class="col-md-3 text-center">
                <h4>Bendahara Jemaat</h4>
                <p>Selvie Liogu mengelola keuangan jemaat dengan transparansi dan akuntabilitas, memastikan segala pemasukan dan pengeluaran tercatat dengan baik.</p>
            </div>
        </div>
    </section>

    <!-- Sistem Informasi Keuangan Section -->
    <section id="sistem" class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-4">Sistem Informasi Keuangan Berbasis Web</h2>
            <p class="text-center">GMAHK Jemaat Pioneer Tumpaan kini memiliki sistem informasi keuangan berbasis web yang bertujuan untuk mempermudah pengelolaan keuangan, transparansi, dan aksesibilitas bagi seluruh jemaat.</p>
        </div>
    </section>

    <!-- Bootstrap and jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>