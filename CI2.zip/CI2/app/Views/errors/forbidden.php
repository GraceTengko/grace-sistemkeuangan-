<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NO AKSES</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 50px;
        }
        h1 {
            color: red;
        }
        .message {
            margin-bottom: 20px;
        }
        .btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>NO AKSES</h1>
    <div class="message">
        <p>You do not have permission to access this page.</p>
    </div>
    <a href="<?= base_url('home'); ?>" class="btn">Kembali</a>
    <!-- Atau, jika ingin mengarahkan ke halaman lain, misalnya login -->
    <!-- <a href="/login" class="btn">Login</a> -->
</body>
</html>
