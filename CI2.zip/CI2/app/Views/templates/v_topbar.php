        
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light topbar mb-4 static-top shadow" style="background-color: #191981;">
                    <head>
                        <meta charset="UTF-8">
                        <meta name="viewport" content="width=device-width, initial-scale=1.0">
                        <title>Variasi Teks Elegan</title>
                        <style>
                            .shadow {
                                text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3); /* Bayangan pada teks */
                            }

                            .title {
                                font-size: 1.1em; /* Ukuran font untuk judul */
                                line-height: 60px; /* Tinggi sejajar dengan container */
                                display: inline-block;
                                color: #ffffff;
                            }

                            .navbar-text {
                                font-size: 1em;
                                color: #ffffff;
                                font-weight: bold;
                            }

                            .align-items-center {
                                display: flex;
                                justify-content: space-between;
                                width: 100%;
                            }
                        </style>
                    </head>
                    <div class="align-items-center">
                        <!-- Title Section (Left) -->
                        <h5 class="font-weight-bold shadow mb-0">
                            <span class="title">GMAHK Pioneer Tumpaan Satu</span>
                        </h5>

                        <!-- User Info Section (Right) -->
                        <div class="navbar-text" style="color: white;">
                            <?php
                            $username = session()->get('sesusername') ?? 'Guest'; // Default 'Guest' jika tidak ada data
                            $role = session()->get('role') ?? 'Guest';
                            ?>
                            <strong>User Aktif:</strong> <?= esc($username); ?> (<?= esc($role); ?>)
                        </div>
                    </div>
                        
                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
 
                        <div class="topbar-divider d-none d-sm-block"></div>
                </nav>
                <!-- End of Topbar -->