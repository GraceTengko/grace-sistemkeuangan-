
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="assets/js/sb-admin-2.min.js"></script>

    <!-- File: templates/v_footer.php -->

</div> <!-- End of Main Content -->

<!-- Script untuk validasi input -->
<script>
    // Validasi nama hanya boleh huruf alfabet dan spasi
    document.getElementById('namapengguna').addEventListener('input', function (e) {
        e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, ''); // Hanya huruf dan spasi yang diperbolehkan
    });

    // Validasi nomor telepon hanya boleh angka dan harus diawali +62
    document.getElementById('telepon').addEventListener('input', function (e) {
        let value = e.target.value;
        if (!value.startsWith('08')) {
            e.target.value = '08';
        } else {
            e.target.value = value.replace(/[^0-9\+]/g, ''); // Hanya angka dan + diizinkan
        }
    });
</script>

<!-- Penutup HTML -->
</body>
</html>

</body>

</html>