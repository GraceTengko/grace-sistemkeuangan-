<!-- Sidebar -->
<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar" style="background-color: #e3f2fd">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center">
        <div class="sidebar-brand-icon">
            <i class="fas fa-church" style="color: #0d47a1;"></i>
        </div>
        <div class="sidebar-brand-text mx-3" style="color: #0d47a1;">KasGereja</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">
    <style>
    .active {
        color: white !important; /* Mengubah warna teks menjadi putih */
        background-color: #2f2fbfb6; /* Warna latar belakang ketika aktif */
    }

    .nav-link {
        color: #1e2a3d; /* Warna default untuk semua link */
    }

    .nav-link.active {
        color: white !important; /* Mengubah warna teks aktif menjadi putih */
        font-weight: bold; /* Membuat teks aktif menjadi bold */
    }

    /* Menjaga warna tulisan saat tombol lain ditekan */
    .nav-link:hover {
        color: #0d47a1; /* Mengubah warna ketika hover */
    }
    </style>

 <!-- Divider -->
<hr class="sidebar-divider my-0">

<ul class="nav" id="admin-menu" style="display: none;">
    <li class="nav-item <?= (uri_string() == 'home') ? 'active' : '' ?>">
        <a class="nav-link <?= (uri_string() == 'home') ? 'active' : '' ?>" href="<?= base_url('home') ?>">
            <i class="fas fa-fw fa-tachometer-alt" style="color: #0d47a1;"></i>
            <span style="font-weight: bold;">Beranda</span>
        </a>
    </li>

    <?php if (in_array(session()->get('role'), ['Operator', 'Ketua', 'Pendeta'])) : ?>
    <li class="nav-item <?= (uri_string() == 'transaksi') ? 'active' : '' ?>">
        <a class="nav-link <?= (uri_string() == 'transaksi') ? 'active' : '' ?>" href="<?= base_url('transaksi') ?>">
            <i class="fas fa-fw fa-money-bill-wave" style="color: #0d47a1;"></i>
            <span style="font-weight: bold;">Transaksi</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if (in_array(session()->get('role'), ['Operator', 'Ketua', 'Pendeta'])) : ?>
    <li class="nav-item <?= (uri_string() == 'kategori') ? 'active' : '' ?>">
        <a class="nav-link <?= (uri_string() == 'kategori') ? 'active' : '' ?>" href="<?= base_url('kategori') ?>">
            <i class="fas fa-fw fa-tags" style="color: #0d47a1;"></i>
            <span style="font-weight: bold;">Kategori</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if (in_array(session()->get('role'), ['Operator', 'Ketua', 'Pendeta'])) : ?>
    <li class="nav-item <?= (uri_string() == 'laporan') ? 'active' : '' ?>">
        <a class="nav-link <?= (uri_string() == 'laporan') ? 'active' : '' ?>" href="<?= base_url('laporan') ?>">
            <i class="fas fa-fw fa-file-alt" style="color: #0d47a1;"></i>
            <span style="font-weight: bold;">Laporan</span>
        </a>
    </li>
    <?php endif; ?>

    <?php if (in_array(session()->get('role'), ['Admin'])) : ?>
    <li class="nav-item <?= (uri_string() == 'pengguna') ? 'active' : '' ?>">
        <a class="nav-link <?= (uri_string() == 'pengguna') ? 'active' : '' ?>" href="<?= base_url('pengguna') ?>">
            <i class="fas fa-fw fa-user" style="color: #0d47a1;"></i>
            <span style="font-weight: bold;">Pengguna</span>
        </a>
    </li>
    <?php endif; ?>

    <li class="nav-item <?= (uri_string() == 'profile') ? 'active' : '' ?>">
        <a class="nav-link <?= (uri_string() == 'profile') ? 'active' : '' ?>" href="<?= base_url('profile') ?>">
            <i class="fas fa-fw fa-user-circle" style="color: #0d47a1;"></i>
            <span style="font-weight: bold;">Profile</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#" onclick="confirmLogout()">
            <i class="fas fa-fw fa-key" style="color: #0d47a1;"></i>
            <span style="font-weight: bold;">Logout</span>
        </a>
    </li>
</ul>

        <script>
            function confirmLogout() {
                // Tampilkan konfirmasi
                if (confirm("Apakah Anda yakin ingin keluar?")) {
                    // Jika pengguna memilih OK, arahkan ke URL logout
                    window.location.href = "<?= base_url('logout') ?>"; // Gunakan base_url untuk URL logout
                }
            }
        </script>
  
    </ul>

<script>
// JavaScript untuk menampilkan menu berdasarkan peran pengguna
document.addEventListener('DOMContentLoaded', () => {
    const userRole = 'admin'; // Ganti dengan role yang sesuai
    document.getElementById(`${userRole}-menu`).style.display = 'block';

    // Fungsi untuk toggle sidebar
    document.getElementById("sidebarToggle").addEventListener("click", function() {
        const sidebar = document.getElementById("accordionSidebar");
        sidebar.classList.toggle("toggled");
    });
});
</script>
