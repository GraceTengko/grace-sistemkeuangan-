<section class="container mb-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center bg-secondary text-white">
                    <h4>Ubah Password</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?= base_url('profile/updatePassword'); ?>">
                        <div class="form-group">
                            <label for="newPassword">Password Baru</label>
                            <input type="password" name="newPassword" id="newPassword" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="confirmPassword">Konfirmasi Password Baru</label>
                            <input type="password" name="confirmPassword" id="confirmPassword" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Update Password</button>
                        <a href="<?= base_url('profile'); ?>" class="btn btn-primary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
