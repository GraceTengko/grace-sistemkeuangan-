<section class="container mb-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header text-center bg-primary text-white">
                    <h4>Profile Pengguna</h4>
                </div>
                <div class="card-body">
                    <!-- Menampilkan pesan sukses jika ada -->
                    <?php if (session()->getFlashdata('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?= session()->getFlashdata('success'); ?>
                        </div>
                    <?php elseif (session()->getFlashdata('error')): ?>
                        <div class="alert alert-danger" role="alert">
                            <?= session()->getFlashdata('error'); ?>
                        </div>
                    <?php endif; ?>

                    <div class="row mb-3">
                        <div class="col-6"><strong>Nama Pengguna</strong></div>
                        <div class="col-6"><?= $user['namapengguna']; ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6"><strong>Telepon</strong></div>
                        <div class="col-6"><?= $user['telepon']; ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6"><strong>Username</strong></div>
                        <div class="col-6"><?= $user['username']; ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-6"><strong>Role</strong></div>
                        <div class="col-6"><?= $user['role']; ?></div>
                    </div>

                    <!-- Tombol untuk mengubah password -->
                    <a href="<?= base_url('profile/ubahpassword'); ?>" class="btn btn-primary">Ubah Password</a>
                </div>
            </div>
        </div>
    </div>
</section>
