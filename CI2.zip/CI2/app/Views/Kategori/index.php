<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

    <style>
        table td, table th {
            color: black; /* Mengatur warna teks dalam tabel menjadi hitam */
        }
    </style>

    <!-- Filter Bulan dan Tahun -->
    <form method="get" action="<?= base_url('kategori'); ?>" class="mb-3">
        <div class="form-group row">
            <!-- Pilihan Tahun -->
            <label for="year" class="col-sm-1 col-form-label">Tahun</label>
            <div class="col-sm-2">
                <select name="year" id="year" class="form-control">
                    <?php 
                    $currentYear = date('Y');
                    for ($year = $currentYear; $year >= $currentYear - 5; $year--) : ?>
                        <option value="<?= $year; ?>" <?= ($year == $selectedYear) ? 'selected' : ''; ?>>
                            <?= $year; ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>

            <!-- Pilihan Bulan -->
            <label for="month" class="col-sm-1 col-form-label">Bulan</label>
            <div class="col-sm-2">
                <select name="month" id="month" class="form-control">
                    <?php 
                    $months = [
                        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April', 
                        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus', 
                        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
                    ];
                    foreach ($months as $num => $name) : ?>
                        <option value="<?= $num; ?>" <?= ($num == $selectedMonth) ? 'selected' : ''; ?>>
                            <?= $name; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-sm-2">
                <button type="submit" class="btn btn-primary">Filter</button>
            </div>
        </div>
    </form>

    <!-- Tabel Data -->
    <div class="card">
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th style="color: black;">No</th>
                        <th style="color: black;">Kategori</th>
                        <th style="color: black;">Saldo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($kategori)) : ?>
                        <tr>
                            <td colspan="4" class="text-center">Data kategori untuk periode ini tidak ditemukan.</td>
                        </tr>
                    <?php else : ?>
                        <?php $i = 1 + (10 * ($currentPage - 1)); ?>
                        <?php foreach ($kategori as $row) : ?>
                            <tr style="color: black;">
                                <td><?= $i++; ?></td>
                                <td><?= esc($row['kategori']); ?></td>
                                <td><?= 'Rp. ' . number_format($row['saldo'], 2, ',', '.'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="d-flex justify-content-center">
                <?= $pager; ?>
            </div>
        </div>
    </div>
</div>
