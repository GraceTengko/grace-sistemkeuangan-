<?php
// Assuming $transaksi is your array of transactions
// Sort the transactions by 'tanggal' in descending order
usort($transaksi, function($a, $b) {
    return strtotime($b['tanggal']) - strtotime($a['tanggal']);
});
?>

<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Menampilkan Detail Transaksi pada Kategori yang Dipilih</h1>

    <style>
        table td, table th {
            color: black; /* Mengatur warna teks dalam tabel menjadi hitam */
        }
    </style>

    <div class="card mb-3">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <a href="<?= base_url('kategori'); ?>" class="btn btn-secondary">
                        Kembali ke Halaman Sebelumnya
                    </a>
                </div>
            </div>
        </div>
    </div>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Nomor Kuitansi</th>
                <th>Tanggal</th>
                <th>Kategori</th>
                <th>Keterangan</th>
                <th>Pemasukan</th>
                <th>Pengeluaran</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($transaksi)) : ?>
                <tr>
                    <td colspan="8" class="text-center">Data transaksi tidak ditemukan.</td>
                </tr>
            <?php else : ?>
                <?php $i = 1; ?>
                <?php foreach ($transaksi as $row) : ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= esc($row['nomor_kuitansi']); ?></td>
                        <td><?= date('d-m-Y', strtotime($row['tanggal'])); ?></td>
                        <td><?= esc($row['kategori']); ?></td>
                        <td><?= esc($row['keterangan']); ?></td>
                        <td><?= number_format($row['pemasukan'], 2, ',', '.'); ?></td>
                        <td><?= number_format($row['pengeluaran'], 2, ',', '.'); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Pagination -->
    <div class="d-flex justify-content-center">
        <?= $pager ? $pager : 'Pagination tidak tersedia'; ?>
    </div>
</div>
