<!-- index.php -->
<div class="container-fluid">
<h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

<style>
        table td, table th {
            color: black; /* Mengatur warna teks dalam tabel menjadi hitam */
        }
</style>

    <!-- Menampilkan Alert jika ada -->
    <?php if (session()->getFlashdata('message')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Berhasil!</strong> <?= session()->getFlashdata('message'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between mb-3">
        <form method="GET" action="<?= base_url('pengguna'); ?>" class="form-inline">
            <input type="text" name="search" class="form-control mr-2" placeholder="Cari Pengguna ... " value="<?= esc($search ?? '') ?>">
            <button type="submit" class="btn btn-outline-success">Cari</button>
        </form>
        <a href="<?= base_url('pengguna/opsipengguna'); ?>" class="btn btn-primary">
            Kelola Akun
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pengguna</th>
                        <th>Telepon</th>
                        <th>Username</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($pengguna)) : ?> <!-- Check if pengguna is empty -->
                        <tr>
                            <td colspan="5" class="text-center">Pengguna ini tidak ditemukan.</td>
                        </tr>
                    <?php else : ?>
                        <?php $i = 1 + (10 * ($currentPage - 1)); // Penomoran sesuai dengan halaman ?>
                        <?php foreach ($pengguna as $row) : ?>
                            <tr>
                                <td scope="row"><?= $i; ?></td>
                                <td><?= esc($row['namapengguna']) ?></td>
                                <td><?= esc($row['telepon']) ?></td>
                                <td><?= esc($row['username']) ?></td>
                                <td><?= esc($row['role']) ?></td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <div class="d-flex justify-content-center">
                <?= $pager->links('default', 'bootstrap_pagination') ?>
            </div>
        </div>
    </div>
</div>