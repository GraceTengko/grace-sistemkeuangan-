<div class="container-fluid">
<h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

    <style>
        table td, table th {
            color: black; /* Mengatur warna teks dalam tabel menjadi hitam */
        }
    </style>

    <!-- Menampilkan Alert jika ada -->
    <?php if(session()->getFlashdata('message')) : ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Berhasil!</strong> <?= session()->getFlashdata('message'); ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <!-- Menampilkan Error jika ada -->
    <?php if (session()->getFlashdata('error')) : ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Gagal!</strong> <?= session()->getFlashdata('error'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between mb-3">
            <form class="form-inline" action="<?= base_url('opsipengguna/search'); ?>" method="get">
                        <input class="form-control mr-2" type="search" name="search" value="<?= esc($search) ?>" placeholder="Cari Pengguna" aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Cari</button>
                    </form>    
            <div>
                    <button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target="#addUserModal">
                        Tambah Akun
                    </button>
                    <a href="<?= base_url('pengguna'); ?>" class="btn btn-secondary">
                        Kembali ke Halaman Data Pengguna
                    </a>
                </div>                
            </div>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pengguna</th>
                        <th>Telepon</th>
                        <th>Username</th>
                        <th>Password (Hidden)</th> 
                        <th>Role</th>
                        <th>Create At</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($pengguna as $row) : ?>
                        <tr>
                            <td><?= $i; ?></td>
                            <td><?= esc($row['namapengguna']) ?></td>
                            <td><?= esc($row['telepon']) ?></td>
                            <td><?= esc($row['username']) ?></td>
                            <td>********</td> <!-- Masked Password -->
                            <td><?= esc($row['role']) ?></td>
                            <td><?= esc($row['created_at']) ?></td>
                            <td>
                                <!-- Button Edit -->
                                <a href="<?= base_url('pengguna/edit/' . $row['id'] . '?search=' . $search) ?>" class="btn btn-warning btn-sm">Edit</a>
                                <!-- Tombol Hapus -->
                                <form action="<?= base_url('pengguna/hapus/' . $row['id'] . '?search=' . $search) ?>" method="post" class="d-inline">
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- Navigasi Halaman -->
            <div class="d-flex justify-content-between">`
                <div>
                    <!-- Menampilkan informasi jumlah data -->
                    <p>Menampilkan <?= count($pengguna); ?> pengguna</p>
                </div>
                <div>
                    <!-- Pagination -->
                <div class="d-flex justify-content-center">
                    <?= $pager->links('default', 'bootstrap_pagination') ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal untuk Tambah Data -->
<div class="modal fade" id="addUserModal" tabindex="-1" role="dialog" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addUserModalLabel">Tambah Akun</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('pengguna/tambah') ?>" method="post">
                    <div class="form-group">
                        <label for="namapengguna" style="color: black;">Nama Pengguna</label>
                        <input type="text" class="form-control" id="namapengguna" name="namapengguna" required>
                    </div>
                    <div class="form-group">
                        <label for="telepon" style="color: black;">Telepon</label>
                        <input type="text" class="form-control" id="telepon" name="telepon" value="08" required 
                            oninput="this.value = '08' + this.value.slice(2).replace(/[^0-9]/g, '');">
                    </div>
                    <div class="form-group">
                        <label for="username" style="color: black;">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password" style="color: black;">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <small class="form-text text-muted">Masukkan password baru.</small>
                    </div>
                    <div class="form-group">
                        <label for="role" style="color: black;">Role</label>
                        <select class="form-control" id="role" name="role" required>
                            <option value="Admin">Admin</option>
                            <option value="Operator">Operator</option>
                            <option value="Pendeta">Pendeta</option>
                            <option value="Ketua">Ketua</option>
                            <option value="Anggota Jemaat">Anggota Jemaat</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>