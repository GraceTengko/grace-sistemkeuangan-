<div class="container-fluid">

    <style>
        table td, table th {
            color: black; /* Mengatur warna teks dalam tabel menjadi hitam */
        }
    </style>

    <!-- Menampilkan Alert jika ada -->
    <?php if(session()->getFlashdata('message')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Berhasil!</strong> <?= session()->getFlashdata('message'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    
        <div class="col-md-6"> <!-- Mengatur lebar kolom -->
            <div class="card">
                <div class="card-body">
                    <!-- Form untuk update data pengguna -->
                    <form action="<?= base_url('pengguna/update/' . $pengguna['id']); ?>" method="post">
                        
                    <h3 class="jumbotron-heading" style="color: black;">Update Data Pengguna</h3>
                        <!-- Nama Pengguna -->
                        <div class="form-group">
                            <label for="namapengguna" style="color: black;">Nama Pengguna</label>
                            <input type="text" class="form-control" id="namapengguna" name="namapengguna" value="<?= $pengguna['namapengguna']; ?>" required>
                        </div>

                        <!-- Telepon -->
                        <div class="form-group">
                            <label for="telepon" style="color: black;">Telepon</label>
                            <input type="tel" class="form-control" id="telepon" name="telepon" value="<?= $pengguna['telepon']; ?>" pattern="\d*" title="Hanya angka yang diperbolehkan" required>
                        </div>

                        <!-- Username -->
                        <div class="form-group">
                            <label for="username" style="color: black;">Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?= $pengguna['username']; ?>" required>
                        </div>

                        <!-- Role Pengguna -->
                        <div class="form-group">
                            <label for="role" style="color: black;">Role</label>
                            <select class="form-control" id="role" name="role" required>
                                <option value="Admin" <?= $pengguna['role'] == 'Admin' ? 'selected' : ''; ?>>Admin</option>
                                <option value="Operator" <?= $pengguna['role'] == 'Operator' ? 'selected' : ''; ?>>Operator</option>
                                <option value="Pendeta" <?= $pengguna['role'] == 'Pendeta' ? 'selected' : ''; ?>>Pendeta</option>
                                <option value="Ketua" <?= $pengguna['role'] == 'Ketua' ? 'selected' : ''; ?>>Ketua</option>
                                <option value="Anggota Jemaat" <?= $pengguna['role'] == 'Anggota Jemaat' ? 'selected' : ''; ?>>Anggota Jemaat</option>
                            </select>
                        </div>

                        <!-- Password -->
                        <div class="form-group">
                            <label for="password" style="color: black;">Password (Kosongkan jika tidak ingin mengubah)</label>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>

                        <!-- Tombol Update dan Kembali -->
                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="<?= base_url('pengguna/opsipengguna'); ?>" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    
</div>
