<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #2c3e50; /* Darker background color */
            background-image: url('/assets/img/bg.jpg'); /* Replace with your image path */
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

        .login-container {
            max-width: 450px;
            margin: 200px auto;
            padding: 40px;
            background-color: rgba(255, 255, 255, 0.85); /* Slightly transparent white */
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3); /* Stronger shadow for 3D effect */
            min-height: 450px;
            backdrop-filter: blur(5px); /* Adds a subtle blur effect */
        }

        .login-header {
            font-size: 2.5em;
            font-weight: bold;
            color: #2c3e50;
            text-align: center;
            margin-top: 20px;
            margin-bottom: 30px;
            transition: transform 0.3s, color 0.3s;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3); /* Text shadow for 3D effect */
        }

        .login-header:hover {
            transform: scale(1.05);
        }

        .form-group label {
            font-weight: bold;
            color: #2c3e50;
        }

        .form-control {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2); /* 3D effect for input fields */
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .form-control:focus {
            box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.4); /* Stronger shadow when focused */
            border-color: #007bff; /* Border color on focus */
        }

        .btn-primary {
            box-shadow: 0px 4px 10px rgba(0, 123, 255, 0.4); /* Shadow for button */
            border-radius: 5px;
        }

    </style>
</head>

<body>
    <div class="login-container">
        <h2 class="login-header">Selamat Datang</h2> <!-- Login header -->

        <?php if (session()->getFlashdata('error')): ?>
            <div class="alert alert-danger">
                <?= session()->getFlashdata('error') ?>
            </div>
        <?php endif; ?>

        <form action="/login-submit" method="post">
            <?= csrf_field() ?> <!-- Token CSRF untuk mencegah serangan CSRF -->
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Masuk</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
