<?php

namespace Config;

use CodeIgniter\Config\RouteCollection;

$routes = Services::routes();

if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

// Rute login dan logout
$routes->get('/', 'Login::index');
$routes->get('/login', 'Login::index');
$routes->post('/login-submit', 'Login::submit');
$routes->get('/logout', 'Auth::logout');

// Rute untuk halaman Home
$routes->get('home', 'Home::index');

// Rute untuk Pengguna
    $routes->get('/', 'Pengguna::index'); // Halaman utama tanpa Opsi
    $routes->get('tambah', 'Pengguna::tambah'); // Halaman form tambah pengguna
    $routes->post('tambah', 'Pengguna::tambah');
    $routes->get('edit/(:num)', 'Pengguna::edit/$1'); // Rute untuk halaman edit pengguna
    $routes->post('update/(:num)', 'Pengguna::update/$1'); // Rute untuk memproses update pengguna
    $routes->get('update/(:num)', 'Pengguna::update/$1'); // Rute untuk memproses update pengguna
    $routes->post('hapus/(:num)', 'Pengguna::hapus/$1'); // Rute untuk menghapus pengguna
    $routes->get('opsipengguna', 'Pengguna::opsipengguna');
    $routes->post('opsipengguna', 'Pengguna::opsipengguna');
    $routes->post('save-user', 'UserController::save');
    $routes->get('opsipengguna/search', 'Pengguna::search');
    $routes->get('search', 'Pengguna::search');

// Rute untuk Laporan
    $routes->get('/', 'Laporan::index');
    $routes->get('getKeuanganData', 'Laporan::getKeuanganData');
    $routes->get('getDetailKeuangan', 'Laporan::getDetailKeuangan');
    $routes->get('detail/(:any)', 'Laporan::detail/$1');


// Rute untuk Kategori
    $routes->get('/', 'Kategori::index');
    $routes->get('/kategori/getTransaksi', 'Kategori:getTransaksi');
    $routes->get('detail/(:any)', 'Kategori::detail/$1'); // Halaman detail transaksi
    $routes->get('kategori/detail/(:segment)', 'Kategori::detail/$1');

// Rute untuk Transaksi
    $routes->get('/', 'Transaksi::index');
    $routes->get('opsitransaksipemasukan', 'Transaksi::opsitransaksipemasukan');
    $routes->get('opsitransaksipengeluaran', 'Transaksi::opsitransaksipengeluaran');    
    $routes->get('edit/(:num)', 'Transaksi::edit/$1');
    $routes->post('update/(:num)', 'Transaksi::update/$1');
    $routes->post('hapus/(:num)', 'Transaksi::hapus/$1');
    $routes->get('hapus/(:num)', 'Transaksi::hapus/$1');
    $routes->post('tambah', 'Transaksi::tambah');
    $routes->get('tambah', 'Transaksi::tambah');
    $routes->get('search', 'Transaksi::search');
    $routes->get('pemasukan', 'Transaksi::pemasukan');
    $routes->get('pengeluaran', 'Transaksi::pengeluaran');

$routes->get('transaksi/opsitransaksi', 'Transaksi::opsitransaksi', ['filter' => 'Operator']);
$routes->post('opsitransaksi', 'Transaksi::opsitransaksi', ['filter' => 'Operator']);
$routes->get('edit/(:num)', 'Transaksi::edit/$1', ['filter' => 'Operator']);
$routes->post('update/(:num)', 'Transaksi::update/$1', ['filter' => 'Operator']);
$routes->post('hapus/(:num)', 'Transaksi::hapus/$1', ['filter' => 'Operator']);
$routes->get('hapus/(:num)', 'Transaksi::hapus/$1', ['filter' => 'Operator']);
$routes->post('tambah', 'Transaksi::tambah', ['filter' => 'Operator']);
$routes->get('tambah', 'Transaksi::tambah', ['filter' => 'Operator']);
$routes->get('search', 'Transaksi::search', ['filter' => 'Operator']);

// Rute untuk Profile
$routes->get('/profile', 'Profile::profile');
$routes->get('/profile/ubahpassword', 'Profile::ubahpassword');
$routes->post('/profile/ubahpassword', 'Profile::ubahpassword');
$routes->post('profile/updatePassword', 'Profile::ubahpassword');

$routes->get('/noakses', 'Noakses::forbidden');

$routes->get('/profile', 'Profile::profile', ['filter' => 'role:Admin,Operator,Ketua,Pendeta,Anggota Jemaat']);

// Rute untuk mengakses file statis
$routes->get('assets/(:any)', function($path) {
    return view('public/assets/' . $path);
});