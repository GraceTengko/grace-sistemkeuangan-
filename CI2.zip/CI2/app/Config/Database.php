<?php

namespace Config;

use CodeIgniter\Database\Config;

/**
 * Database Configuration
 */
class Database extends Config
{
    /**
     * The directory that holds the Migrations and Seeds directories.
     */
    public string $filesPath = APPPATH . 'Database' . DIRECTORY_SEPARATOR;

    /**
     * Lets you choose which connection group to use if no other is specified.
     */
    public string $defaultGroup = 'default';

    /**
     * The default database connection.
     *
     * @var array<string, mixed>
     */
    public array $default = [
        'DSN'          => '',
        'hostname'     => '', // Dihilangkan dari deklarasi ini
        'username'     => '', // Default empty, nanti diatur dalam constructor
        'password'     => '', // Default empty, nanti diatur dalam constructor
        'database'     => '', // Default empty, nanti diatur dalam constructor
        'DBDriver'     => 'MySQLi',
        'DBPrefix'     => '',
        'pConnect'     => false,
        'DBDebug'      => '',
        'charset'      => 'utf8mb4',
        'DBCollat'     => 'utf8mb4_unicode_ci',
        'swapPre'      => '',
        'encrypt'      => false,
        'compress'     => false,
        'strictOn'     => false,
        'failover'     => [],
        'port'         => 3306, // Nilai default jika tidak ditemukan
        'numberNative' => false,
        'dateFormat'   => [
            'date'     => 'Y-m-d',
            'datetime' => 'Y-m-d H:i:s',
            'time'     => 'H:i:s',
        ],
    ];

    public function __construct()
    {
        parent::__construct();

        // Memastikan hostname menggunakan logika yang tepat berdasarkan lingkungan
        $this->default['hostname'] = (ENVIRONMENT === 'production') 
            ? getenv('database.default.hostname') 
            : 'localhost';
        
        // Mengatur username, password, dan database dari environment variables
        $this->default['username'] = getenv('database.default.username') ?: 'root'; 
        $this->default['password'] = getenv('database.default.password') ?: ''; // Kosongkan jika tidak ada password
        $this->default['database'] = getenv('database.default.database') ?: 'kasgreja_db'; // Ganti dengan nama database Anda

        // Mengatur port jika diperlukan, gunakan 3306 jika tidak ada
        $this->default['port'] = getenv('database.default.port') ?: 3306;

        // Pastikan kita selalu menetapkan grup database ke 'tests' saat menjalankan pengujian otomatis
        if (ENVIRONMENT === 'testing') {
            $this->defaultGroup = 'tests';
        }
    }

    /**
     * Pengaturan koneksi pengujian (untuk PHPUnit).
     */
    public array $tests = [
        'DSN'         => '',
        'hostname'    => '127.0.0.1',
        'username'    => '',
        'password'    => '',
        'database'    => ':memory:',
        'DBDriver'    => 'SQLite3',
        'DBPrefix'    => 'db_',
        'pConnect'    => false,
        'DBDebug'     => true,
        'charset'     => 'utf8',
        'DBCollat'    => '',
        'swapPre'     => '',
        'encrypt'     => false,
        'compress'    => false,
        'strictOn'    => false,
        'failover'    => [],
        'port'        => 3306,
        'foreignKeys' => true,
        'busyTimeout' => 1000,
        'dateFormat'  => [
            'date'     => 'Y-m-d',
            'datetime' => 'Y-m-d H:i:s',
            'time'     => 'H:i:s',
        ],
    ];
}
