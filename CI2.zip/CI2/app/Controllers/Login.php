<?php 

namespace App\Controllers;

use App\Models\PenggunaModel;

class Login extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new PenggunaModel();
    }

    public function index()
    {
        return view('login'); // Memanggil tampilan login
    }

    public function submit()
    {
        // Validasi input
        $validationRules = [
            'username' => 'required|alpha_numeric|min_length[3]',
            'password' => 'required|min_length[6]',
        ];

        // Ambil data dari form login
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Cari pengguna berdasarkan username
        $user = $this->model->where('username', $username)->first();

        if ($user && password_verify($password, $user['password'])) {
            // Simpan data ke session
            session()->set([
                'sesusername' => $user['username'],
                'user_id' => $user['id'],
                'role' => $user['role'], // contoh: admin, operator
                'isLoggedIn' => true,
            ]);

            // Redirect berdasarkan peran pengguna
            switch ($user['role']) {
                case 'admin':
                    return redirect()->to('/admin/dashboard');
                case 'operator':
                    return redirect()->to('/operator/dashboard');
                case 'anggota':
                    return redirect()->to('/anggota/dashboard');
                default:
                    return redirect()->to('/home');
            }
        } else {
            // Jika login gagal
            return redirect()->back()->with('error', 'Username atau password salah.')->withInput();
        }
    }
}
