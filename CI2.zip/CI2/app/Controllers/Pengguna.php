<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\PenggunaModel;

class Pengguna extends Controller
{
    protected $model;

    public function __construct()
    {
        // Initialize the model in the constructor
        $this->model = new PenggunaModel();
    }

    public function index()
    {
        $data['judul'] = 'Daftar Pengguna'; // Menyimpan judul untuk halaman
        $search = $this->request->getGet('search') ?? ''; // Mencari berdasarkan nama pengguna
    
        // Mengambil data pengguna dengan pencarian dan urutan terbaru
        $penggunaModel = new PenggunaModel();
        $data['pengguna'] = $penggunaModel->like('namapengguna', $search) // Pencarian berdasarkan nama pengguna
                                           ->orderBy('created_at', 'DESC') // Urutkan berdasarkan waktu input, terbaru di atas
                                           ->paginate(10); // Menampilkan 10 pengguna per halaman
        $data['pager'] = $penggunaModel->pager; // Menyimpan pager untuk pagination
        $data['currentPage'] = $this->request->getVar('page') ? $this->request->getVar('page') : 1; // Menyimpan halaman saat ini
        $data['search'] = $search; // Menyimpan nilai pencarian
    
        // Load the views for displaying the user list
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar');
        echo view('templates/v_topbar');
        echo view('pengguna/index', $data); // Mengirim data ke view
        echo view('templates/v_footer');
    }      

    public function opsipengguna()
    {
        // Ambil kata kunci pencarian
        $search = $this->request->getGet('search') ?? ''; // Mencari berdasarkan nama pengguna
        
        // Jumlah data per halaman
        $dataPerPage = 10;
    
        // Ambil data pengguna dengan atau tanpa pencarian dan urutkan
        if (!empty($search)) {
            // Jika ada pencarian, gunakan like
            $pengguna = $this->model->like('namapengguna', $search)
                                    ->orderBy('created_at', 'DESC') // Urutkan berdasarkan waktu input
                                    ->paginate($dataPerPage);
        } else {
            // Jika tidak ada pencarian, ambil semua data
            $pengguna = $this->model->orderBy('created_at', 'DESC') // Urutkan berdasarkan waktu input
                                    ->paginate($dataPerPage);
        }
    
        // Ambil pager dan data lainnya
        $pager = \Config\Services::pager();
        $data = [
            'pengguna' => $pengguna,
            'pager'    => $pager,
            'search'   => $search, // Menyimpan nilai pencarian untuk ditampilkan kembali di form
            'judul'    => ''
        ];
    
        // Memuat view untuk halaman opsi pengguna
        echo view('templates/v_header', $data);
        echo view('templates/v_topbar');
        echo view('pengguna/opsipengguna', $data); // Mengirimkan data ke view
    }          

    public function tambah()
    {
        // Ambil username dari input
        $username = $this->request->getPost('username');

        // Cek apakah username sudah ada di database
        $existingUser = $this->model->where('username', $username)->first();
        
        if ($existingUser) {
            // Jika username sudah ada, kirim pesan error dan kembalikan ke form tambah
            return redirect()->back()->with('error', 'Username sudah digunakan, silakan pilih username lain.')->withInput();
        }

        // Jika username belum ada, lanjutkan untuk menambahkan pengguna baru
        $data = [
            'namapengguna' => $this->request->getPost('namapengguna'),
            'telepon'      => $this->request->getPost('telepon'),
            'username'     => $username,
            'password'     => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT), // Hash password
            'role'         => $this->request->getPost('role'),
        ];

        // Insert data pengguna baru ke database
        if ($this->model->insert($data)) {
            return redirect()->to(base_url('pengguna/opsipengguna'))->with('message', 'Pengguna berhasil ditambahkan!');
        } else {
            return redirect()->back()->with('error', 'Gagal menambah pengguna.')->withInput();
        }
    }

    public function edit($id)
    {
        $data['pengguna'] = $this->model->find($id);
    
        if (!$data['pengguna']) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Pengguna tidak ditemukan');
        }
    
        // Menambahkan judul untuk ditampilkan di topbar
        $data['judul'] = 'Edit Pengguna';
    
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar');
        echo view('templates/v_topbar', $data); // Mengirimkan data judul ke v_topbar
        echo view('pengguna/edit', $data);
        echo view('templates/v_footer');
    }    

    public function hapus($id)
    {
        // Ambil nilai search dari query string
        $search = $this->request->getGet('search') ?? '';
    
        if ($this->model->delete($id)) {
            session()->setFlashdata('message', 'Data berhasil dihapus!');
            // Redirect ke halaman opsipengguna dengan parameter search
            return redirect()->to(base_url('pengguna/opsipengguna'));
        } else {
            session()->setFlashdata('message', 'Data gagal dihapus!');
        }
    
        return redirect()->to(base_url('pengguna'));
    }

    public function update($id)
    {
        // Mengambil data dari request form
        $data = [
            'namapengguna' => $this->request->getPost('namapengguna'),
            'telepon'      => $this->request->getPost('telepon'),
            'username'     => $this->request->getPost('username'),
            'role'         => $this->request->getPost('role'),
        ];
    
        // Debugging: Lihat apakah data sudah benar sebelum diupdate
        log_message('debug', 'Data yang akan diupdate: ' . json_encode($data));
    
        // Mengambil password baru jika diisi, lalu hash
        $password = $this->request->getPost('password');
        if (!empty($password)) {
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
        }
    
        // Mengatur aturan validasi untuk update
        $this->model->setValidationRulesForUpdate($id);
        
        // Validasi data
        if (!$this->validate($this->model->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
    
        // Mengambil parameter 'search' dari URL
        $search = $this->request->getGet('search') ?? '';
    
        // Lakukan update data di database dengan model
        if ($this->model->update($id, $data)) {
            log_message('debug', 'Update berhasil untuk ID: ' . $id);
            session()->setFlashdata('message', 'Pengguna berhasil diperbarui');
            return redirect()->to(base_url('pengguna/opsipengguna?search=' . $search));
        } else {
            log_message('error', 'Gagal memperbarui pengguna dengan ID: ' . $id);
            return redirect()->back()->withInput()->with('peringatan', 'Gagal memperbarui pengguna');
        }
    }
      
    public function search()
    {
        // Ambil input pencarian dari URL
        $search = $this->request->getGet('search') ?? '';

        // Mengambil data pengguna berdasarkan pencarian
        $pengguna = $this->model->like('namapengguna', $search)->paginate(10);
        $pager = $this->model->pager;

        // Siapkan data untuk dikirim ke view
        $data = [
            'judul' => 'Hasil Pencarian Pengguna',
            'pengguna' => $pengguna,
            'pager' => $pager,
            'search' => $search,
            'currentPage' => $this->request->getVar('page') ? $this->request->getVar('page') : 1,
        ];

        // Load the views
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar');
        echo view('templates/v_topbar');
        echo view('pengguna/index', $data); // Mengirim data pencarian ke view
        echo view('templates/v_footer');
    }
}
