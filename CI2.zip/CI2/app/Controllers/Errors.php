<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Noakses extends Controller
{
    public function forbidden()
    {
        
        echo view('noakses/forbidden');
      
    }
}
