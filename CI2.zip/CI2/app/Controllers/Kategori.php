<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\KategoriModel;
use App\Models\TransaksiModel;

class Kategori extends Controller
{
    protected $kategoriModel;
    protected $transaksiModel;

    public function __construct()
    {
        // Inisialisasi model
        $this->kategoriModel = new KategoriModel();
        $this->transaksiModel = new TransaksiModel(); // Untuk mendapatkan total saldo berdasarkan transaksi
    }

    public function index()
    {
        $year = $this->request->getGet('year') ?? date('Y'); // Default tahun berjalan
        $month = $this->request->getGet('month') ?? date('n'); // Default bulan berjalan
        $currentPage = $this->request->getVar('page') ?? 1;
    
        // Daftar nama bulan
        $months = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
            5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
            9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
        ];
    
        // Mengambil total pemasukan dan pengeluaran per kategori berdasarkan bulan dan tahun
        $saldos = $this->transaksiModel->getTotalSaldoByKategoriAndMonthYear($month, $year);
    
        // Persiapkan data untuk ditampilkan di view
        $data['kategori'] = [];
        foreach ($saldos as $saldo) {
            $totalSaldo = $saldo['total_pemasukan'] - $saldo['total_pengeluaran'];
            $data['kategori'][] = [
                'kategori' => $saldo['kategori'],
                'saldo' => $totalSaldo,
            ];
        }
    
        // Pagination setup
        $pager = \Config\Services::pager();
        $dataPerPage = 10;
        $totalKategori = count($data['kategori']);
        $data['kategori'] = array_slice($data['kategori'], ($currentPage - 1) * $dataPerPage, $dataPerPage);
    
        $data['pager'] = $pager->makeLinks($currentPage, $dataPerPage, $totalKategori, 'bootstrap_pagination');
        $data['currentPage'] = $currentPage;
        $data['judul'] = 'Laporan Saldo Bulan ' . $months[$month] . ' Tahun ' . $year;
        $data['selectedYear'] = $year;
        $data['selectedMonth'] = $month;
    
        // Kirim data ke view
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar');
        echo view('templates/v_topbar');
        echo view('kategori/index', $data);
        echo view('templates/v_footer');
    }
    
    public function update($id)
    {
        if ($this->request->getMethod() === 'post') {
            $data = $this->request->getPost(); // Ambil data dari form
            $this->kategoriModel->update($id, $data); // Update kategori dengan data baru
            session()->setFlashdata('message', 'Kategori berhasil diupdate!'); // Set flash message
            return redirect()->to('/kategori'); // Redirect ke halaman kategori
        }

        // Ambil data kategori untuk ditampilkan di form
        $kategori = $this->kategoriModel->find($id);
        return view('kategori/edit', ['kategori' => $kategori]);
    }
}