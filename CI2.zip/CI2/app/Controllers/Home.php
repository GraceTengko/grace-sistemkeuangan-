<?php

namespace App\Controllers;

class Home extends BaseController
{
    protected $session;

    public function __construct(){
        $this->session = \Config\Services::session();
    }

    public function index()
    {
        if (!$this->session->has('sesusername')) {
            return redirect()->to("/login");
        }
        $role = session()->get('role'); // Ambil role dari session
        $data = [
            'judul' => 'Homepage',
            'role' => $role
        ];
    
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar');
        echo view('templates/v_topbar');
        echo view('home/index', $data);
        echo view('templates/v_footer');
    }
}