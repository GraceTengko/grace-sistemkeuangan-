<?php 

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\TransaksiModel;

class Transaksi extends Controller
{
    protected $transaksiModel;

    public function __construct()
    {
        // Initialize transaksi model
        $this->transaksiModel = new TransaksiModel();

        // Pastikan direktori uploads/kuitansi ada
        $this->checkOrCreateDirectory();
    }

    private function checkOrCreateDirectory()
    {
        // Path ke folder 'uploads/kuitansi/'
        $uploadPath = WRITEPATH . 'uploads/kuitansi/';
        
        // Jika folder tidak ada, buat folder tersebut
        if (!is_dir($uploadPath)) {
            mkdir($uploadPath, 0775, true); // Membuat folder dengan izin 775 (read-write untuk pemilik dan grup)
        }
    }

    public function index()
    {
        $currentPage = $this->request->getVar('page') ? (int)$this->request->getVar('page') : 1;
        $search = $this->request->getVar('search');
        $role = session()->get('role'); // Ambil role dari sesi pengguna
    
        $transaksi = [];
    
        // Logika untuk pencarian atau akses berdasarkan role
        if ($role === 'Anggota Jemaat') {
            // Jika role adalah Anggota Jemaat
            if ($search) {
                $transaksi = $this->transaksiModel->where('nomor_kuitansi', $search)->findAll();
            }
        } else {
            // Untuk role lain, tampilkan semua data atau hasil pencarian
            if ($search) {
                $transaksi = $this->transaksiModel->where('nomor_kuitansi', $search)->paginate(10, 'default');
            } else {
                $transaksi = $this->transaksiModel->orderBy('created_at', 'DESC')->paginate(10, 'default');
            }
        }
    
        $totalPemasukan = 0;
        $totalPengeluaran = 0;
    
        foreach ($transaksi as $row) {
            $totalPemasukan += $row['pemasukan'];
            $totalPengeluaran += $row['pengeluaran'];
        }
    
        $data = [
            'judul' => '',
            'transaksi' => $transaksi,
            'totalPemasukan' => $totalPemasukan,
            'totalPengeluaran' => $totalPengeluaran,
            'pager' => ($role !== 'Anggota Jemaat') ? $this->transaksiModel->pager : null, // Pagination hanya untuk role selain Anggota Jemaat
            'currentPage' => $currentPage,
            'search' => $search,
        ];
    
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar', $data);
        echo view('templates/v_topbar', $data);
        echo view('transaksi/index', $data);
        echo view('templates/v_footer');
    }    

    public function pemasukan()
    {
        $currentMonth = date('m'); // Bulan sekarang
        $currentYear = date('Y');  // Tahun sekarang
    
        // Ambil data transaksi pemasukan
        $transaksi = $this->transaksiModel->where('MONTH(tanggal)', $currentMonth)
                                          ->where('YEAR(tanggal)', $currentYear)
                                          ->where('pemasukan >', 0) // Filter hanya pemasukan
                                          ->findAll();

        $data['judul'] = 'Data Pemasukan';

        return view('transaksi/pemasukan', [
            'transaksi' => $transaksi,
            'judul' => $data['judul']
        ]);
    }

    public function pengeluaran()
    {
        $currentMonth = date('m'); // Bulan sekarang
        $currentYear = date('Y');  // Tahun sekarang
    
        // Ambil data transaksi pengeluaran
        $transaksi = $this->transaksiModel->where('MONTH(tanggal)', $currentMonth)
                                          ->where('YEAR(tanggal)', $currentYear)
                                          ->where('pengeluaran >', 0) // Filter hanya pengeluaran
                                          ->findAll();

        $data['judul'] = 'Data Pengeluaran';

        return view('transaksi/pengeluaran', [
            'transaksi' => $transaksi,
            'judul' => $data['judul']
        ]);
    }

    public function opsitransaksipemasukan()
    {
        $currentPage = $this->request->getVar('page') ? (int)$this->request->getVar('page') : 1;
        $search = $this->request->getVar('search');
        
        $transaksi = $this->transaksiModel
            ->where('pemasukan >', 0)
            ->like('keterangan', $search ?? '')
            ->orderBy('tanggal', 'DESC')
            ->paginate(10, 'default');
    
        $data = [
            'judul' => 'Kelola Transaksi Pemasukan',
            'transaksi' => $transaksi,
            'pager' => $this->transaksiModel->pager,
            'currentPage' => $currentPage,
        ];
    
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar', $data);
        echo view('templates/v_topbar', $data);
        echo view('transaksi/opsitransaksipemasukan', $data);
        echo view('templates/v_footer');
    }
    
    public function opsitransaksipengeluaran()
    {
        $currentPage = $this->request->getVar('page') ? (int)$this->request->getVar('page') : 1;
        $search = $this->request->getVar('search');
        
        $transaksi = $this->transaksiModel
            ->where('pengeluaran >', 0)
            ->like('keterangan', $search ?? '')
            ->orderBy('tanggal', 'DESC')
            ->paginate(10, 'default');
    
        $data = [
            'judul' => 'Kelola Transaksi Pengeluaran',
            'transaksi' => $transaksi,
            'pager' => $this->transaksiModel->pager,
            'currentPage' => $currentPage,
        ];
    
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar', $data);
        echo view('templates/v_topbar', $data);
        echo view('transaksi/opsitransaksipengeluaran', $data);
        echo view('templates/v_footer');
    }    

    public function tambah()
    {
        $nomor_kuitansi = $this->request->getPost('nomor_kuitansi');
        $tanggal = $this->request->getPost('tanggal');
        $kategori = $this->request->getPost('kategori');
        $keterangan = $this->request->getPost('keterangan');
        $pemasukan = $this->request->getPost('pemasukan');
        $pengeluaran = $this->request->getPost('pengeluaran');
        
        $file = $this->request->getFile('picture');
        $filePath = null;

        if ($file && $file->isValid() && !$file->hasMoved()) {
            $uploadPath = WRITEPATH . 'uploads/kuitansi/';
            $file->move($uploadPath);
            $filePath = 'uploads/kuitansi/' . $file->getName();
        }

        $data = [
            'nomor_kuitansi' => $nomor_kuitansi,
            'tanggal' => $tanggal,
            'kategori' => $kategori,
            'keterangan' => $keterangan,
            'pemasukan' => $pemasukan,
            'pengeluaran' => $pengeluaran,
            'created_at' => date('Y-m-d H:i:s'),
            'picture' => $filePath,
        ];

        if ($this->transaksiModel->insert($data)) {
            session()->setFlashdata('message', 'Transaksi berhasil ditambahkan.');
        } else {
            session()->setFlashdata('error', 'Terjadi kesalahan saat menambahkan transaksi.');
        }

        return redirect()->to('/transaksi');
    }

    public function hapus($id)
    {
        if ($this->transaksiModel->delete($id)) {
            session()->setFlashdata('message', 'Transaksi berhasil dihapus.');
        } else {
            session()->setFlashdata('error', 'Gagal menghapus transaksi.');
        }

        return redirect()->to(base_url('transaksi'));
    }

    public function edit($id)
    {
        $data['transaksi'] = $this->transaksiModel->find($id);

        if (!$data['transaksi']) {
            session()->setFlashdata('error', 'Transaksi tidak ditemukan.');
            return redirect()->to(base_url('transaksi'));
        }

        $data['judul'] = 'Edit Transaksi';

        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar', $data);
        echo view('templates/v_topbar', $data);
        echo view('transaksi/edit', $data);
        echo view('templates/v_footer');
    }

    public function update($id)
    {
        $transaksi = $this->transaksiModel->find($id);

        if (!$transaksi) {
            session()->setFlashdata('error', 'Transaksi tidak ditemukan.');
            return redirect()->to(base_url('transaksi'));
        }

        $nomor_kuitansi = $this->request->getPost('nomor_kuitansi');
        $tanggal = $this->request->getPost('tanggal');
        $kategori = $this->request->getPost('kategori');
        $keterangan = $this->request->getPost('keterangan');
        $pemasukan = $this->request->getPost('pemasukan');
        $pengeluaran = $this->request->getPost('pengeluaran');
        $file = $this->request->getFile('picture');
        
        $filePath = $transaksi['picture'];

        if ($file && $file->isValid() && !$file->hasMoved()) {
            $uploadPath = WRITEPATH . 'uploads/kuitansi/';
            $file->move($uploadPath);
            $filePath = 'uploads/kuitansi/' . $file->getName();
        }

        $data = [
            'nomor_kuitansi' => $nomor_kuitansi,
            'tanggal' => $tanggal,
            'kategori' => $kategori,
            'keterangan' => $keterangan,
            'pemasukan' => $pemasukan,
            'pengeluaran' => $pengeluaran,
            'picture' => $filePath,
        ];

        if ($this->transaksiModel->update($id, $data)) {
            session()->setFlashdata('message', 'Transaksi berhasil diperbarui.');
        } else {
            session()->setFlashdata('error', 'Terjadi kesalahan saat memperbarui transaksi.');
        }

        return redirect()->to(base_url('transaksi'));
    }
}
