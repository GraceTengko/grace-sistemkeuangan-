<?php 

namespace App\Controllers;

use App\Models\KategoriModel;
use App\Models\TransaksiModel;

class Laporan extends BaseController
{
    protected $kategoriModel;
    protected $transaksiModel;

    public function __construct()
    {
        $this->session = \Config\Services::session();
        $this->kategoriModel = new KategoriModel();
        $this->transaksiModel = new TransaksiModel();
    }

    public function index()
    {
        if($this->session->has('sesusername') == ""){
            return redirect()->to("/login");
        }
    
        // Mengambil data kategori untuk laporan
        $kategori = $this->kategoriModel->findAll(); // Mengambil semua kategori
    
        // Mengambil data dari model untuk laporan bulanan
        $laporanBulanan = $this->transaksiModel->getLaporanBulanan(); // Metode untuk mengambil data
    
        // Hitung saldo kumulatif
        $saldoSisa = 0;
        foreach ($laporanBulanan as &$laporan) {
            $pemasukan = isset($laporan['pemasukan']) ? floatval($laporan['pemasukan']) : 0;
            $pengeluaran = isset($laporan['pengeluaran']) ? floatval($laporan['pengeluaran']) : 0;
    
            // Saldo kumulatif
            $saldoSisa += $pemasukan - $pengeluaran;
    
            // Tambahkan saldo ke setiap laporan
            $laporan['saldo'] = $saldoSisa;
        }
    
        $data = [
            'judul' => 'Laporan',
            'kategori' => $kategori,
            'laporanBulanan' => $laporanBulanan,
            'pager' => $this->transaksiModel->pager,
            'search' => $this->request->getGet('search')
        ];
    
        return view('templates/v_header', $data)
            . view('templates/v_sidebar')
            . view('templates/v_topbar')
            . view('laporan/index')
            . view('templates/v_footer');
    }    

    public function getKeuanganData()
    {
        $tahun = (int) $this->request->getGet('tahun');

        // Mengambil data dari model, pastikan ada filter berdasarkan tahun
        $data = $this->transaksiModel
            ->select('MONTH(tanggal) as bulan, SUM(pemasukan) as pemasukan, SUM(pengeluaran) as pengeluaran')
            ->where('YEAR(tanggal)', $tahun)
            ->groupBy('bulan')
            ->findAll();

        // Format data jika perlu
        foreach ($data as &$item) {
            $item['pemasukan'] = $item['pemasukan'] !== null ? floatval($item['pemasukan']) : 0;
            $item['pengeluaran'] = $item['pengeluaran'] !== null ? floatval($item['pengeluaran']) : 0;
        }

        // Hitung saldo kumulatif
        $saldo = 0;
        foreach ($data as &$item) {
            $pemasukan = $item['pemasukan'];
            $pengeluaran = $item['pengeluaran'];

            $saldo += $pemasukan - $pengeluaran; // Saldo kumulatif

            // Format pemasukan, pengeluaran, dan saldo menjadi mata uang setelah perhitungan
            $item['pemasukan'] = 'Rp. ' . number_format($pemasukan, 2, ',', '.');
            $item['pengeluaran'] = 'Rp. ' . number_format($pengeluaran, 2, ',', '.');
            $item['saldo'] = 'Rp. ' . number_format($saldo, 2, ',', '.'); // Format saldo
        }

        // Mengembalikan data dalam format JSON
        return $this->response->setJSON($data);
    } 

    public function getDetailKeuangan()
    {
        // Mendapatkan parameter 'bulan' dan 'tahun' dari URL
        $bulan = (int) $this->request->getGet('bulan'); 
        $tahun = (int) $this->request->getGet('tahun'); // Tambahkan tahun
    
        // Validasi bulan dan tahun
        if ($bulan < 1 || $bulan > 12 || $tahun < 2000) {
            return redirect()->to('/laporan')->with('error', 'Bulan atau tahun tidak valid.');
        }
    
        // Ambil jumlah data per halaman
        $perPage = 10;
    
        // Mengambil nomor halaman saat ini
        $currentPage = (int) $this->request->getGet('page') ? (int) $this->request->getGet('page') : 1;
    
        // Ambil data detail keuangan berdasarkan bulan dan tahun dengan pagination
        $detailData = $this->transaksiModel
            ->where('MONTH(tanggal)', $bulan) // Ambil berdasarkan bulan dari tanggal
            ->where('YEAR(tanggal)', $tahun)  // Ambil berdasarkan tahun dari tanggal
            ->paginate($perPage); // Menggunakan paginate untuk mengambil data sesuai halaman
    
        // Format data jika perlu
        foreach ($detailData as &$item) {
            $item['pemasukan'] = $item['pemasukan'] !== null ? 'Rp. ' . number_format($item['pemasukan'], 2, ',', '.') : 'Rp. 0,00';
            $item['pengeluaran'] = $item['pengeluaran'] !== null ? 'Rp. ' . number_format($item['pengeluaran'], 2, ',', '.') : 'Rp. 0,00';
        }
    
        // Kirim data ke view
        $data = [
            'bulan' => $bulan,
            'tahun' => $tahun,  // Pastikan ini ditambahkan
            'detailData' => $detailData,
            'pager' => $this->transaksiModel->pager, // Mengambil pager untuk pagination
            'currentPage' => $currentPage, // Menyimpan informasi halaman saat ini
        ];
    
        // Debugging
        log_message('debug', 'Detail Data: ' . print_r($detailData, true));
        log_message('debug', 'Bulan: ' . $bulan . ', Tahun: ' . $tahun);
        log_message('debug', 'Current Page: ' . $currentPage);
    
        return view('templates/v_header', $data) // Memuat header
            . view('templates/v_topbar') // Memuat topbar
            . view('laporan/detail', $data); // Memuat view detail keuangan
    }       
       
    public function detail()
    {
        $bulan = (int) $this->request->getGet('bulan');
        $tahun = (int) $this->request->getGet('tahun');
    
        // Ambil daftar kategori
        $kategoriList = $this->kategoriModel->findAll();
    
        // Ambil data detail keuangan berdasarkan bulan dan tahun
        $perPage = 10;
        $currentPage = (int) $this->request->getGet('page') ? (int) $this->request->getGet('page') : 1;
    
        $detailData = $this->transaksiModel->getPagination($bulan, $tahun, $perPage);
    
        // Format data
        foreach ($detailData as &$item) {
            $item['pemasukan'] = floatval($item['pemasukan']);
            $item['pengeluaran'] = floatval($item['pengeluaran']);
            $item['pemasukan'] = 'Rp. ' . number_format($item['pemasukan'], 2, ',', '.');
            $item['pengeluaran'] = 'Rp. ' . number_format($item['pengeluaran'], 2, ',', '.');
        }
    
        $data = [
            'bulan' => $bulan,
            'tahun' => $tahun,
            'kategori' => $this->request->getGet('kategori') ?? '', // Kategori yang dipilih
            'kategoriList' => $kategoriList, // Daftar kategori
            'detailData' => $detailData,
            'pager' => $this->transaksiModel->pager,
            'currentPage' => $currentPage,
        ];
    
        return view('templates/v_header', $data)
            . view('templates/v_sidebar')
            . view('templates/v_topbar')
            . view('laporan/detail', $data)
            . view('templates/v_footer');
    }
    
}